from datetime import datetime

entry = input("Enter entry time (HH:MM): ")
exit_time = input("Enter exit time (HH:MM): ")
vehicle = input("Enter vehicle type (bike/car/bus): ").lower()

try:
    start = datetime.strptime(entry, "%H:%M")
    end = datetime.strptime(exit_time, "%H:%M")

    if vehicle not in ["bike", "car", "bus"]:
        print("Invalid vehicle type")
    else:
        minutes = (end - start).total_seconds() / 60

        if minutes < 0:
            minutes += 1440

        hours = max(1, int((minutes + 59) // 60))
        rates = {"bike": 10, "car": 20, "bus": 40}
        daily_limits = {"bike": 100, "car": 200, "bus": 400}

        days = max(1, (hours + 23) // 24)
        fee = min(hours * rates[vehicle], daily_limits[vehicle] * days)

        if end < start:
            fee += 50

        if hours > 24:
            fee += 100

        print("Parking duration:", hours, "hours")
        print("Vehicle:", vehicle)
        print("Total parking fee: Rs.", fee)

except ValueError:
    print("Invalid time! Enter time in HH:MM format.")