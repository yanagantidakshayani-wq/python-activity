n = int(input("Enter number of products: "))
budget = float(input("Enter shopping budget: "))
products = []
total = 0

for i in range(n):
    name = input("Enter product name: ")
    price = float(input("Enter price: "))
    quantity = int(input("Enter quantity: "))

    if price < 0 or quantity < 0:
        print("Invalid product details")
        continue

    amount = price * quantity
    products.append([name, price, quantity, amount])
    total += amount

discount = 0
if total >= 5000:
    discount = total * 0.10
elif total >= 2000:
    discount = total * 0.05

final_total = total - discount
print("Total:", total)
print("Discount:", discount)
print("Final amount:", final_total)

if final_total > budget:
    excess = final_total - budget
    print("Reduce purchases by at least Rs.", round(excess, 2))
    for p in products:
        while p[2] > 0 and excess > 0:
            p[2] -= 1
            excess -= p[1]
            print("Reduce quantity of", p[0])
else:
    print("Shopping is within budget.")