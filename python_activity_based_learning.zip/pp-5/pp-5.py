entry = input("Enter entry time (HH:MM): ")
exit_time = input("Enter exit time (HH:MM): ")
vehicle = input("Enter vehicle type (bike/car/bus): ").lower()

try:
    eh, em = map(int, entry.split(":"))
    xh, xm = map(int, exit_time.split(":"))

    if not (0 <= eh < 24 and 0 <= em < 60 and
            0 <= xh < 24 and 0 <= xm < 60):
        print("Invalid time")
    elif vehicle not in ["bike", "car", "bus"]:
        print("Invalid vehicle type")
    else:
        start = eh * 60 + em
        end = xh * 60 + xm

        if end < start:
            end += 1440
        minutes = end - start
        hours = max(1, (minutes + 59) // 60)

        rates = {"bike": 10, "car": 20, "bus": 40}
        daily_limit = {"bike": 100, "car": 200, "bus": 400}
        fee = min(hours * rates[vehicle], daily_limit[vehicle])

        if end >= 1440:
            fee += 50

        if hours > 24:
            fee += 100

        print("Parking duration:", hours, "hours")
        print("Vehicle type:", vehicle)
        print("Total parking fee: Rs.", fee)

except ValueError:
    print("Invalid time format. Use HH:MM.")