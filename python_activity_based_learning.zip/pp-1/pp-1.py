n = int(input("Enter number of subjects: "))
max_marks = 100
pass_marks = 35
grace_limit = int(input("Enter maximum grace marks: "))
marks_list = []
failed = []

for i in range(n):
    marks = int(input("Enter subject marks: "))
    if marks < 0 or marks > max_marks:
        print("Invalid marks")
        continue
    marks_list.append(marks)
    if marks < pass_marks:
        failed.append(len(marks_list) - 1)

grace_used = 0
for i in failed:
    needed = pass_marks - marks_list[i]
    if grace_used + needed <= grace_limit:
        marks_list[i] += needed
        grace_used += needed

total = sum(marks_list)
print("\nFinal Subject Marks:", marks_list)
print("Grace Marks Used:", grace_used)
print("Total Marks:", total)

if len(marks_list) != n:
    print("Result incomplete due to invalid marks")
elif any(m < pass_marks for m in marks_list):
    print("Result: Fail")
elif total >= n * 75:
    print("Result: Distinction")
elif total >= n * 60:
    print("Result: First Class")
elif total >= n * 50:
    print("Result: Second Class")
else:
    print("Result: Pass")