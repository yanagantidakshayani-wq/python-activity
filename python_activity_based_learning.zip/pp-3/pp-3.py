balance = float(input("Enter initial balance: "))
n = int(input("Enter number of transactions: "))
limit = float(input("Enter maximum withdrawal limit: "))
deposits = 0
withdrawals = 0
successful = 0
failed = 0

for i in range(n):
    print("\n1. Deposit  2. Withdraw")
    choice = int(input("Enter transaction type: "))
    amount = float(input("Enter amount: "))

    if amount <= 0:
        print("Invalid amount")
        failed += 1
    elif choice == 1:
        balance += amount
        deposits += amount
        successful += 1
        print("Deposit successful")
    elif choice == 2:
        if amount > limit:
            print("Withdrawal limit exceeded")
            failed += 1
        elif amount > balance:
            print("Insufficient balance")
            failed += 1
        else:
            balance -= amount
            withdrawals += amount
            successful += 1
            print("Withdrawal successful")
    else:
        print("Invalid transaction type")
        failed += 1

print("\n----- Transaction Summary -----")
print("Total Deposits:", deposits)
print("Total Withdrawals:", withdrawals)
print("Successful Transactions:", successful)
print("Failed Transactions:", failed)
print("Final Balance:", round(balance, 2))