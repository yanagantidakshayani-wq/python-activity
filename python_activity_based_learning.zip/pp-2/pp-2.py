attended = int(input("Enter classes attended: "))
total = int(input("Enter total classes conducted: "))
threshold = float(input("Enter required attendance percentage: "))

if total <= 0 or attended < 0 or attended > total:
    print("Invalid attendance details")
else:
    percentage = attended / total * 100
    print("Current Attendance:", round(percentage, 2), "%")

    if percentage >= threshold:
        print("You are already eligible")
        print("Minimum additional classes required: 0")
    elif threshold >= 100:
        print("Attend all future classes to reach 100%")
    else:
        required = 0
        while (attended + required) / (total + required) * 100 < threshold:
            required += 1

        print("Minimum consecutive classes to attend:", required)
        print("Future attendance scenarios:")

        for future in [5, 10, 20, 30]:
            new_attended = attended + future
            new_total = total + future
            new_percentage = new_attended / new_total * 100
            print("After", future, "classes:",
                  round(new_percentage, 2), "%")