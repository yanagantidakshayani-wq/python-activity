n = int(input("Enter number of products: "))

for i in range(n):
    name = input("Enter product name: ")
    opening = int(input("Enter opening stock: "))
    incoming = int(input("Enter incoming quantity: "))
    dispatched = int(input("Enter dispatched quantity: "))
    closing = int(input("Enter actual closing stock: "))
    minimum = int(input("Enter minimum required stock: "))

    if opening < 0 or incoming < 0 or dispatched < 0 or closing < 0:
        print("Invalid stock details")
        continue

    expected = opening + incoming - dispatched

    print("\nProduct:", name)
    print("Expected Closing Stock:", expected)
    print("Actual Closing Stock:", closing)

    if expected == closing:
        print("Stock matches. No discrepancy.")
    else:
        print("Stock discrepancy:", closing - expected)

    replenishment = max(0, minimum - closing)
    print("Replenishment Required:", replenishment)