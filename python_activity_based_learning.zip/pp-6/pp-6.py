capacity = float(input("Enter tank capacity: "))
level = float(input("Enter initial water level: "))
threshold = float(input("Enter target water level: "))
days = int(input("Enter number of days: "))

if capacity <= 0 or level < 0 or level > capacity or days <= 0:
    print("Invalid input")
else:
    reached = False

    for day in range(1, days + 1):
        inflow = float(input("Enter inflow for day " + str(day) + ": "))
        outflow = float(input("Enter outflow for day " + str(day) + ": "))

        if inflow < 0 or outflow < 0:
            print("Invalid quantities")
            continue

        level = level + inflow - outflow

        if level > capacity:
            print("Day", day, ": Overflow detected")
            level = capacity
        elif level < 0:
            print("Day", day, ": Water shortage detected")
            level = 0

        print("Water level:", level)

        if not reached and level >= threshold:
            print("Threshold first reached on day", day)
            reached = True

    if not reached:
        print("Threshold was not reached")