n = int(input("Enter number of applicants: "))
applicants = []

for i in range(n):
    name = input("Enter applicant name: ")
    math = float(input("Enter Mathematics marks: "))
    science = float(input("Enter Science marks: "))
    english = float(input("Enter English marks: "))
    attendance = float(input("Enter attendance percentage: "))

    aggregate = (math + science + english) / 3

    if math >= 50 and science >= 50 and english >= 40 and aggregate >= 60 and attendance >= 75:
        applicants.append([name, aggregate, attendance])
        print(name, "is eligible")
    else:
        print(name, "is not eligible")

applicants.sort(key=lambda x: (-x[1], -x[2], x[0]))

print("\nRanked List of Eligible Applicants")
if not applicants:
    print("No eligible applicants found")
else:
    for rank, applicant in enumerate(applicants, 1):
        print(rank, applicant[0], "Aggregate:", round(applicant[1], 2),
              "Attendance:", applicant[2], "%")