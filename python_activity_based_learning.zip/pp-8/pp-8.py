n = int(input("Enter number of vehicles: "))
budget = float(input("Enter fuel budget: "))
best_cost = float("inf")
best_vehicle = ""

for i in range(n):
    name = input("Enter vehicle name: ")
    distance = float(input("Enter journey distance (km): "))
    mileage = float(input("Enter mileage (km/l): "))
    price = float(input("Enter fuel price per litre: "))
    reserve = float(input("Enter reserve fuel (litres): "))

    if distance <= 0 or mileage <= 0 or price <= 0 or reserve < 0:
        print("Invalid vehicle details")
        continue

    fuel = distance / mileage
    total_fuel = fuel + reserve
    cost = total_fuel * price

    print("Vehicle:", name)
    print("Fuel required with reserve:", round(total_fuel, 2), "litres")
    print("Journey cost with reserve: Rs.", round(cost, 2))

    if cost <= budget and cost < best_cost:
        best_cost = cost
        best_vehicle = name

if best_vehicle:
    print("Lowest-cost feasible vehicle:", best_vehicle)
    print("Total fuel cost: Rs.", round(best_cost, 2))
else:
    print("No vehicle is feasible within the budget.")